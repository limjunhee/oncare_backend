package oncare_backend.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity 
@Table (name="inquirycategory")
@NoArgsConstructor @AllArgsConstructor @Data @Builder 
public class InquiryCategoryEntity {
    @Id 
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column(name = "inquiry_category_no")
    private Integer inquiryCategoryNo;
    
    @Column (nullable = false , length = 50)
    private String inquiryCategoryName;
}
